_DEBUG = true;return {
["BundleIconFile"] = "appicon.png";
["MainInterfaceFile"] = "interface.xui";
["BundleInfoDictionaryVersion"] = "6.0";
["PackageControl"] = 
{
["AuthorEmail"] = "作者电子邮件地址";
["Copyright"] = "版权信息";
["AuthorName"] = "作者名";
["Tags"] = "标签";
["Homepage"] = "网站地址";
["Description"] = "描述信息";
};
["BundleVersion"] = "0.1";
["BundleDisplayName"] = "IDFA-debug";
["Executable"] = "main.lua";
["BundleName"] = "IDFA-debug";
["BundleIdentifier"] = "IDFA";
};